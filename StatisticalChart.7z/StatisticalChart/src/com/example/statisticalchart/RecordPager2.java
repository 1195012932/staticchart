package com.example.statisticalchart;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by liyachao on 2015/3/20.
 */
public class RecordPager2 extends Fragment {
	private View view;
	private LineChartView chartView;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {

		view = inflater.inflate(R.layout.record_layout_two, null);
		chartView = (LineChartView) view.findViewById(R.id.chart);

		return view;
	}

	@Override
	public void onResume() {
		super.onResume();
		chartView.start(MainActivity.flag2);
	}
}
